import { Request, Response, Express } from "express";
import { UserController } from "../controllers/user";
import { MovieController } from "../controllers/movie";
import { authMiddleware } from "./middleware/auth";

export class Routes {
  private static userController = new UserController();
  private static movieController = new MovieController();

  public static buildRoutes(app: Express) {
    app.route("/").get((req: Request, res: Response) => {
      res.json({ result: "success" });
    });

    // Route pour l'inscription des utilisateurs
    app.route("/register").post((req: Request, res: Response) => {
      Routes.userController.registerUser(req, res);
    });

    app.route("/login").post(authMiddleware, (req: Request, res: Response) => {
      Routes.userController.getUserByEmail(req, res);
    });

    // Route pour récupérer un utilisateur par email
    app.route("/userByEmail").post(Routes.userController.getUserByEmail);

    // Route pour lister les utilisateurs (pour l'administration ou les tests)
    app.route("/userlist").get((req: Request, res: Response) => {
      Routes.userController.list(req, res);
    });

    app.route("/userByEmail").post((req: Request, res: Response) => {
      Routes.userController.getUserByEmail(req, res);
    });

    
    // app.route("/movies").get(authMiddleware, (req: Request, res: Response) => {
    //   Routes.movieController.allmovies(req, res);
    // });
    
    // app.route("/movies").post((req: Request, res: Response) => {
      //   Routes.movieController.addmovie(req, res);
      // });


    // Protège toutes les routes liées aux films avec authMiddleware
    app.route("/movies")
    .get(authMiddleware, Routes.movieController.allmovies)
    .post(authMiddleware, Routes.movieController.addmovie);


    app.route("/movies/:id").get((req: Request, res: Response) => {
      Routes.movieController.read(req, res);
    });

    app.route("/movies/:id").put((req: Request, res: Response) => {
      Routes.movieController.updatemovie(req, res);
    });

    app.route("/movies/:id").delete((req: Request, res: Response) => {
      Routes.movieController.remove(req, res);
    });

    

  }
}
