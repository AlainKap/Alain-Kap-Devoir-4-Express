import { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";


export const authMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Liste des URL qui ne nécessitent pas d'authentification
  const exceptions = ["/login", "/register", "/userlist"];

  // Passe à la suite pour les URL dans les exceptions
  if (exceptions.includes(req.originalUrl)) {
    return next();
  }

  const secret = process.env.SECRET;
  if (!secret) {
    return res
      .status(500)
      .json({ status: "error", data: "Please configure environment file" });
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ status: "error", data: "Invalid token" });
  }
  const token = authHeader.slice(7);

  try {
    // Vérifie et décode le token
    const decoded = jwt.verify(token, secret) as jwt.JwtPayload;

    // Attache l'ID utilisateur et les rôles au req pour les utiliser plus tard
    req.userId = decoded.sub;
    req.roles = decoded.roles;

    next(); // Passe au middleware/routeur suivant
  } catch (error) {
    return res.status(401).json({ status: "error", data: "Invalid token" });
  }
};

// étendre l'interface Request de Express pour inclure userId et roles
declare global {
  namespace Express {
    interface Request {
      userId?: number;
      userEmail?: string;
      roles?: string[];
    }
  }
}
