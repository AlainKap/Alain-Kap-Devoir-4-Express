import { Request, Response } from "express";
import { prisma } from "../app";
import { Movie } from "@prisma/client";


export class MovieController {


  async allmovies(req: Request, res: Response) {
    const userId = req.userId;
    const page = req.query.page ? parseInt(req.query.page as string) : 1;
    const take = req.query.take ? parseInt(req.query.take as string) : 4;
    const skip = (page - 1) * take;  
    try {
      const [count, movies] = await prisma.$transaction([
        prisma.movie.count({
          where: {
            userId: userId, 
          },
        }),
        prisma.movie.findMany({
          where: {
            userId: userId,
          },
          select: {
            id: true,
            nom: true,
            annee: true,
            realisateur: true,
            synopsis: true,
            createdAt: true,
            updatedAt: true,
          },
          take,
          skip,
        }),
      ]);  
      const totalPages = Math.ceil(count / take);  
      return res.json({ data: movies, total: count, totalPages });
    } catch (error) {
      return res
        .status(500)
        .json({
          error: "Une erreur est survenue lors de la récupération des movies.",
        });
    }
}

async addmovie(req: Request, res: Response) {
  const movieData = req.body;
  const userId = req.userId;
  if (!movieData || !userId) {
    return res.status(400).json({
      status: "error",
      data: "Données du film ou userId manquant",
    });
  }
  try {
    const movie = await prisma.movie.create({
      data: {
        ...movieData,
        userId: userId,
      },
    });
    return res.json({ status: "success", data: movie });
  } catch (e) {
    console.error("Erreur lors de l'ajout du film:", e);
    return res.status(500).json({ status: "error", data: "Erreur lors de l'ajout du film" });
  }
}  

  async read(req: Request, res: Response) {
    const movie = await prisma.movie.findFirst({
      where: {
        id: +req.params.id,
      },
    });
    return res.json({ data: movie });
  }

  // Méthode pour mettre à jour un movie
  async updatemovie(req: Request, res: Response) {
    const movieData = req.body;
  
    let errors = await this.validation(movieData);  
    if (errors.length > 0) {
      return res.status(400).json({ status: "error", errors });
    }  
    try {
      const updatedMovie = await prisma.movie.update({
        where: {
          id: +req.params.id,
        },
        data: {
          id: movieData.id,
          nom: movieData.nom,
          annee: movieData.annee,
          realisateur: movieData.realisateur,
          synopsis: movieData.synopsis,          
        },
      });  
      return res.json({ status: "success", data: updatedMovie });
    } catch (e) {
      console.error("Erreur lors de la mise à jour du movie:", e);
      return res.status(500).json({ status: "error", data: "Erreur lors de la mise à jour du movie" });
    }
  }  

  // Méthode pour supprimer un movie
  async remove(req: Request, res: Response) {
    try {
      const id = +req.params.id;
      let result = await prisma.movie.delete({
        where: {
          id: id,
        },
      });
      return res.json({ result: result });
    } catch (e) {
      return res.status(500).json({ status: "error", data: "error" });
    }
  }

  // Méthode pour valider les données du formlaire de création d'un film
  private async validation(data: Movie) {
    let errors: string[] = [];
  
    if (!data) {
      errors.push("Aucun film lié");
      return errors;
    }
  
    if (!data.nom || data.nom.length === 0) {
      errors.push("Le nom du film est requis");
    }
  
    if (!data.annee || data.annee < 1890) { 
      errors.push("L'année du film est invalide ou manquante");
    }
  
    if (!data.realisateur || data.realisateur.length < 2) {
      errors.push("Le nom du réalisateur est trop court");
    }
  
    if (!data.synopsis || data.synopsis.length < 5) {
      errors.push("Le synopsis est trop court");
    }
  
    return errors;
  }
  


}

  // étendre l'interface Request de Express pour inclure userId et roles
  declare global {
    namespace Express {
      interface Request {
        userEmail?: string;
        userId?: string;
        roles?: string[];
      }
    }}

