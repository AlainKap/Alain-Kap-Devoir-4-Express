import { Request, Response } from "express";
import { prisma } from "../app";
import { User } from "@prisma/client";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export class UserController {

  async list(req: Request, res: Response) {
    const data = await prisma.user.findMany({
      include: {
        role: true,
      },
    });

    return res.json({ data });
  }

  async create(req: Request, res: Response) {
    const data: User = req.body.data;
    if (!data.password) {
      return res.status(500).json({ status: "error", data: "error" });
    }
    if (!data.email) {
      return res.status(500).json({ status: "error", data: "error" });
    }
    if (!data.name) {
      return res.status(500).json({ status: "error", data: "error" });
    }

    const count = await prisma.user.count({ where: { email: data.email } });
    if (count != 0) {
      return res
        .status(500)
        .json({ status: "error", data: "User already exists" });
    }

    const saltRounds = 10;
    bcrypt.hash(data.password, saltRounds, async (err, hash) => {
      if (hash) {
        data.password = hash;
        const user = await prisma.user.create({ data });
        return res.json({ status: "success", data: { id: user.id } });
      }
    });
  }

  async registerUser(req: Request, res: Response) {
    console.log(req.body);
    const postData: User = req.body.postData;
    if (!postData.password) {
      return res
        .status(400)
        .json({ status: "error", message: "Password is required" });
    }
    if (!postData.email) {
      return res
        .status(400)
        .json({ status: "error", message: "Email is required" });
    }
    if (!postData.name) {
      return res
        .status(400)
        .json({ status: "error", message: "Full name is required" });
    }

    const count = await prisma.user.count({where: {email: postData.email}});
    if (count != 0) {
        return res.status(500).json({status: 'error', message: "User already exists"});
    }

    const saltRounds = 10;
    bcrypt.hash(postData.password, saltRounds, async (err, hash) => {
        if (err) {
            return res.status(500).json({status: 'error', message: "Error hashing password"});
        }
        if (hash) {
            // Utilisez directement les informations de postData, mais remplacez le mot de passe par le hash.
            const user = await prisma.user.create({
                data: {
                    email: postData.email,
                    password: hash, // Utilisez le hash ici.
                    name: postData.name
                    // Ajoutez d'autres champs si nécessaire.
                }
            });
            return res.json({status: 'success', data: {id: user.id}});
        } else {
            return res.status(500).json({status: 'error', message: "Failed to create user"});
        }
        });

    // try {
    //   const count = await prisma.user.count({
    //     where: { email: postData.email },
    //   });
    //   if (count != 0) {
    //     return res
    //       .status(409)
    //       .json({ status: "error", message: "User already exists" });
    //   }

    //   const saltRounds = 10;
    //   const hash = await bcrypt.hash(postData.password, saltRounds);

    //   // Proceed with creating the user using the hash
    //   const user = await prisma.user.create({
    //     data: {
    //       email: postData.email,
    //       password: hash,
    //       name: postData.name,
    //       // Other fields as necessary
    //     },
    //   });
    //   return res.status(201).json({ status: "success", data: { id: user.id } });
    // } catch (err) {
    //   console.error(err);
    //   return res
    //     .status(500)
    //     .json({ status: "error", message: "Failed to create user" });
    // }
  }

  async login(req: Request, res: Response) {
    const body = req.body;

    if (!body.login || !body.password) {
      return res
        .status(500)
        .json({ status: "error", data: "User or password incorrect" });
    }
    const user = await prisma.user.findFirst({
      where: {
        email: body.login,
      },
      include: {
        role: true,
      },
    });
    const roles = user?.role.map((role) => role.name);
    if (!user) {
      return res
        .status(500)
        .json({ status: "error", data: "User or password incorrect" });
    }
    bcrypt.compare(body.password, user.password, (err, result) => {
      if (result) {
        const secret = process.env.SECRET;
        if (!secret) {
          return res.json({
            status: "error",
            data: "Please configure environment file",
          });
        }
        const token = jwt.sign(
          { userId: user.id, name: user.name, email: user.email, roles },
          secret,
          { expiresIn: "12h" }
        );
        return res.json({ status: "success", secret: token });
      } else {
        return res.json({ status: "error" });
      }
    });
  }

  public async getUserIdByEmail(req: Request, res: Response) {
    const { email } = req.body;
    try {
      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      const { password, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      console.error(error);
      res.status(500).send("Erreur interne du serveur.");
    }
  }

  async getUserByEmail(req: Request, res: Response) {
    const body = req.body;
    if (!body.login || !body.password) {
      return res
        .status(500)
        .json({ status: "error", data: "User or password incorrect" });
    }
    const user = await prisma.user.findFirst({
      where: {
        email: body.login,
      },
      include: {
        role: true,
      },
    });
    const roles = user?.role.map((role) => role.name);
    if (!user) {
      return res
        .status(500)
        .json({ status: "error", data: "User or password incorrect" });
    }
    bcrypt.compare(body.password, user.password, (err, result) => {
      if (result) {
        const secret = process.env.SECRET;
        if (!secret) {
          return res.json({
            status: "error",
            data: "Please configure environment file",
          });
        }
        const token = jwt.sign(
          { sub: user.id, name: user.name, email: user.email, roles },
          secret,
          { expiresIn: "12h" }
        );
        return res.json({ status: "success", secret: token });
      } else {
        return res.json({ status: "error" });
      }
    });
  }
}
