import { User } from "@prisma/client"; // Assurez-vous que le chemin est correct

declare global {
  namespace Express {
    interface Request {
      userId?: number;
      userEmail?: string;
      user?: User; // Ou le type approprié pour votre utilisateur
      roles?: string[];
    }
  }
}
