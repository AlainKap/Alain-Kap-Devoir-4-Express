Base node API build with Vite, Express and Prisma

# Installation

Renomer .env.exemple en .env

Commande: *npx prisma generate*

# Démarrage

Commande: *npm run dev*

# Migration

Pour executer une migration:
*npx prisma migrate dev --name init*

Vous pouvez changer le "init" en un autre nom pour nommer votre migration

# Lancement de la gui DB
*npx prisma studio*
